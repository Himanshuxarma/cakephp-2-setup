-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2024 at 08:05 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cakephp`
--

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `country_id`) VALUES
(1, 'ANDHRA PRADESH', 105),
(2, 'ASSAM', 105),
(3, 'ARUNACHAL PRADESH', 105),
(4, 'BIHAR', 105),
(5, 'GUJRAT', 105),
(6, 'HARYANA', 105),
(7, 'HIMACHAL PRADESH', 105),
(8, 'JAMMU & KASHMIR', 105),
(9, 'KARNATAKA', 105),
(10, 'KERALA', 105),
(11, 'MADHYA PRADESH', 105),
(12, 'MAHARASHTRA', 105),
(13, 'MANIPUR', 105),
(14, 'MEGHALAYA', 105),
(15, 'MIZORAM', 105),
(16, 'NAGALAND', 105),
(17, 'ORISSA', 105),
(18, 'PUNJAB', 105),
(19, 'RAJASTHAN', 105),
(20, 'SIKKIM', 105),
(21, 'TAMIL NADU', 105),
(22, 'TRIPURA', 105),
(23, 'UTTAR PRADESH', 105),
(24, 'WEST BENGAL', 105),
(25, 'DELHI', 105),
(26, 'GOA', 105),
(27, 'PONDICHERY', 105),
(28, 'LAKSHDWEEP', 105),
(29, 'DAMAN & DIU', 105),
(30, 'DADRA & NAGAR', 105),
(31, 'CHANDIGARH', 105),
(32, 'ANDAMAN & NICOBAR', 105),
(33, 'UTTARANCHAL', 105),
(34, 'JHARKHAND', 105),
(35, 'CHATTISGARH', 105);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact_number` int(10) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `state` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `contact_number`, `email`, `password`, `address`, `state`, `is_admin`, `status`, `created`, `modified`) VALUES
(1, 'Himanshu', 'Sharma', 2147483647, 'himanshuxarma28@gmail.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 1, 1, '2024-02-20 21:07:21', '2024-02-20 21:07:21'),
(2, 'Rahul', 'Sharma', 2147483647, 'rahul@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 19, 0, 1, '2024-02-20 21:16:03', '2024-02-20 21:16:03'),
(3, 'test', 'test', 1234561234, 'test@trsts.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 1, 0, 1, '2024-02-21 13:09:07', '2024-02-21 13:09:07'),
(4, 'test', 'tet', 2147483647, 'test@test.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 13:11:43', '2024-02-21 13:11:43'),
(5, 'yrdy', 'trdydf', 2147483647, 'test@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 13:17:18', '2024-02-21 13:17:18'),
(6, 'yrdy', 'trdydf', 2147483647, 'test1@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 13:18:02', '2024-02-21 13:18:02'),
(7, 'ramesh', 'singh', 1234567890, 'ramesh@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 2, 0, 1, '2024-02-21 13:53:59', '2024-02-21 13:53:59'),
(8, 'ramesh', 'singh', 1234567890, 'ramesh1@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 2, 0, 1, '2024-02-21 13:55:00', '2024-02-21 13:55:00'),
(9, 'ramesh', 'singh', 1234567890, 'ramesh12@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 2, 0, 1, '2024-02-21 13:55:42', '2024-02-21 13:55:42'),
(10, 'ramesh', 'singh', 1234567890, 'ramesh123@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 2, 0, 1, '2024-02-21 13:56:13', '2024-02-21 13:56:13'),
(11, 'Parthivi', 'Sharma', 2147483647, 'parthivi@mailinator.com', '8315145ea5bd5de422f158ac5bfa11949ae61f61', 'test', 1, 0, 1, '2024-02-21 14:44:02', '2024-02-21 14:44:02'),
(12, 'Parthivi', 'Sharma', 2147483647, 'parthivi12@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 3, 0, 1, '2024-02-21 14:46:31', '2024-02-21 14:46:31'),
(13, 'Bear', 'Masha', 2147483647, 'masha@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 14:48:10', '2024-02-21 14:48:10'),
(14, 'masha', 'bear', 2147483647, 'bear@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 14:49:04', '2024-02-21 14:49:04'),
(15, 'Deepak', 'Sharma', 2147483647, 'deepak@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 14:51:23', '2024-02-21 14:51:23'),
(16, 'Kun', 'Hun', 1234567895, 'kun@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-21 19:51:02', '2024-02-21 19:51:02'),
(17, 'visa', 'master', 2147483647, 'visa@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 13:10:37', '2024-02-23 13:10:37'),
(18, 'Amitabh', 'Bachchan', 2147483647, 'amit@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 13:39:45', '2024-02-23 13:39:45'),
(19, 'Shazia', 'Rehman', 2147483647, 'shazia@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 13:43:13', '2024-02-23 13:43:13'),
(20, 'Mei', 'Jiunga', 2147483647, 'mein@Mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 13:44:50', '2024-02-23 13:44:50'),
(21, 'test', 'test', 2147483647, 'test123@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 2, 1, 1, '2024-02-23 13:46:46', '2024-02-23 13:46:46'),
(22, 'test', 'test', 2147483647, 'test23@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'tst', 4, 1, 1, '2024-02-23 13:47:39', '2024-02-23 13:47:39'),
(23, 'good', 'Night', 2147483647, 'good@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 13:49:28', '2024-02-23 13:49:28'),
(24, 'tedha', 'medha', 1234567543, 'tedha@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'tsttest', 4, 1, 1, '2024-02-23 14:44:52', '2024-02-23 14:44:52'),
(25, 'Vikram', 'Vedha', 2147483647, 'vikram@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 1, 1, '2024-02-23 14:46:11', '2024-02-23 14:46:11'),
(26, 'vikram', 'ji', 2147483647, 'ji@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 14:46:59', '2024-02-23 14:46:59'),
(27, 'Khatu', 'shyam', 1234543212, 'khatu@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 14:48:22', '2024-02-23 14:48:22'),
(28, 'Usaki', 'sheikh', 2147483647, 'usaki@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 2, 1, 1, '2024-02-23 14:49:18', '2024-02-23 14:49:18'),
(29, 'First', 'Name', 2147483647, 'first@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 14:51:33', '2024-02-23 14:51:33'),
(30, 'First', 'Second', 2147483647, 'first12@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 14:57:02', '2024-02-23 14:57:02'),
(31, 'pakar', 'pakar', 2147483647, 'pakar@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 15:00:14', '2024-02-23 15:00:14'),
(32, 'Oakar', 'Pakar', 2147483647, 'pakar1@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 15:02:51', '2024-02-23 15:02:51'),
(33, 'build', 'War', 2147483647, 'build@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 1, 1, '2024-02-23 15:16:44', '2024-02-23 15:16:44'),
(34, 'test', 'test', 2147483647, 'test43@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 15:21:27', '2024-02-23 15:21:27'),
(35, 'Hello', 'One', 1232123212, 'hello@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 15:27:14', '2024-02-23 15:27:14'),
(36, 'Game', 'Over', 2147483647, 'game@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 15:30:41', '2024-02-23 15:30:41'),
(37, 'test', 'test', 2147483647, 'test54@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 2, 1, 1, '2024-02-23 15:33:51', '2024-02-23 15:33:51'),
(38, 'Yahan', 'Vahan', 1232142433, 'yahan@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 15:42:43', '2024-02-23 15:42:43'),
(39, 'Atithi', 'tum', 1234567654, 'atithi@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 15:44:24', '2024-02-23 15:44:24'),
(40, 'Idher', 'dekha', 2147483647, 'idhar@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 3, 1, 1, '2024-02-23 15:45:45', '2024-02-23 15:45:45'),
(41, 'school', 'life', 1234567654, 'arisu@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 6, 1, 1, '2024-02-23 15:46:55', '2024-02-23 15:46:55'),
(42, 'Hi', 'hello', 1234567876, 'hi@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 15:48:06', '2024-02-23 15:48:06'),
(43, 'Arisu', 'Hena', 1234543245, 'arisu2@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 6, 1, 1, '2024-02-23 15:49:18', '2024-02-23 15:49:18'),
(44, 'Kuina', 'kuki', 1324567654, 'kuina@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 6, 1, 1, '2024-02-23 15:52:59', '2024-02-23 15:52:59'),
(45, 'Yakuja', 'shareef', 1234321343, 'yakuza@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 15:59:52', '2024-02-23 15:59:52'),
(46, 'Angelina', 'Jolie', 2147483647, 'Angelina@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 10, 1, 1, '2024-02-23 16:04:05', '2024-02-23 16:04:05'),
(47, 'Placement', 'India', 1234321344, 'place@mailinator.com', '2ff2818d9c689851d7f413b12fa8f42fe32cac44', 'test', 19, 1, 1, '2024-02-23 16:05:19', '2024-02-23 16:05:19'),
(48, 'Shanti', 'singh', 2147483647, 'shanti@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 16:14:20', '2024-02-23 16:14:20'),
(49, 'Himanshu', 'Sharma', 2147483647, 'death@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 6, 1, 1, '2024-02-23 16:15:58', '2024-02-23 16:15:58'),
(50, 'beach324', 'jaisa', 2147483647, 'beach@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 16:17:09', '2024-02-23 16:17:09'),
(51, 'abcd', 'efgh', 2147483647, 'abcd@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 0, 1, '2024-02-23 16:18:16', '2024-02-23 16:18:16'),
(52, 'salman', 'khan', 2147483647, 'salman@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 4, 1, 1, '2024-02-23 16:19:14', '2024-02-23 16:19:14'),
(53, 'alice', 'series', 1234553245, 'alice@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 0, 1, '2024-02-23 16:27:16', '2024-02-23 16:27:16'),
(54, 'someone', 'another', 2147483647, 'someone@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', '123456', 7, 1, 1, '2024-02-23 16:33:58', '2024-02-23 16:33:58'),
(55, 'hemant', 'shikre', 1111155555, 'hemant@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 1, 1, '2024-02-23 16:36:07', '2024-02-23 19:24:21'),
(56, 'Masha', 'Bear', 2147483647, 'masha12@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 0, 1, '2024-02-23 18:30:51', '2024-02-23 18:30:51'),
(57, 'sachin', 'tendulkar', 2147483647, 'sachin@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 7, 0, 1, '2024-02-23 18:39:52', '2024-02-23 18:39:52'),
(58, 'Sujan', 'husan', 2147483647, 'sujan@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 0, 1, '2024-02-23 18:44:29', '2024-02-23 18:44:29'),
(59, 'Ethan', 'Hunt', 2147483647, 'ethan@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 5, 1, 1, '2024-02-23 19:02:43', '2024-02-23 19:02:43'),
(60, 'Adam', 'Sandler', 2147483647, 'adam@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 3, 0, 1, '2024-02-23 19:03:41', '2024-02-23 19:03:41'),
(61, 'Ankit', 'Sharma', 2147483647, 'ankit@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 3, 0, 1, '2024-02-23 19:04:23', '2024-02-23 19:04:23'),
(62, 'Amitabh', 'Trivedi', 2147483647, 'amit123@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 1, 0, 1, '2024-02-23 19:05:51', '2024-02-23 19:25:48'),
(63, 'Krishna', 'Kant Sharma', 2147483647, 'krishna@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'test', 19, 1, 1, '2024-02-23 19:26:54', '2024-02-23 19:26:54'),
(64, 'Himanshu', 'Sharma', 2147483647, 'kun654@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', '3-DH-170, Jai AMbe NAgar, Rangbari', 19, 0, 1, '2024-02-23 19:46:58', '2024-02-23 19:46:58'),
(65, 'Himanshu', 'Sharma', 2147483647, '789kun@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', '3-DH-170, Jai AMbe NAgar, Rangbari', 19, 0, 1, '2024-02-23 19:50:15', '2024-02-23 19:50:15'),
(66, 'Himanshu', 'Sharma', 2147483647, 'ku78n@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', 'Hathoj', 19, 0, 0, '2024-02-23 19:51:53', '2024-02-23 20:04:02'),
(67, 'Himanshu123', 'Sharma', 2147483647, 'kun951@mailinator.com', '5ac61fefaaaf166c0a17bacfb0ecf5bb482c7cf3', '3-DH-170, Jai AMbe NAgar, Rangbari', 19, 0, 0, '2024-02-23 19:56:38', '2024-02-23 20:03:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
